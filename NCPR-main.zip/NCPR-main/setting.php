<?php
// SMTP Configuration for PHPMailer
$host = "smtp.gmail.com"; 
$port = 465; // Use 587 if SSL doesn’t work
$smtpSecure = "ssl"; // Use "tls" for port 587

$username = "gerardocabojr@gmail.com"; // Your Gmail address
$hostPassword = "yzofdggrhnmkkqgc"; // 16-character App Password

// Sender Information
$sender = "gerardocabojr@gmail.com"; 
$senderName = "Your App Name"; 
?>
