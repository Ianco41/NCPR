<?php
header('Location: loginform.php');
exit(); 
?>